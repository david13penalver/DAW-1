# Exercici 1 - David Peñalver
Canvi 1
Canvi 2
