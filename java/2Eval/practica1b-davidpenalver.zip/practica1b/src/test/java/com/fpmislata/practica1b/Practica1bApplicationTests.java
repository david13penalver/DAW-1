package com.fpmislata.practica1b;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practica1bApplicationTests {

	@Test
	void contextLoads() {
	}

}
