package com.fpmislata.examen2.persistence.repository.mapper;

public class ActorMapper {


}
