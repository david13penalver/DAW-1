package com.fpmislata.examen2.persistence.dao.entity;

public class ActorEntity {

    private int id;
    private String name;

    public ActorEntity(int id, String name) {
        this.id = id;
        this.name = name;
    }

}
