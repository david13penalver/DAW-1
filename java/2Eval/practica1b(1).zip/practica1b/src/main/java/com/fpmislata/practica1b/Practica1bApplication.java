package com.fpmislata.practica1b;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practica1bApplication {

	public static void main(String[] args) {
		SpringApplication.run(Practica1bApplication.class, args);
	}

}
