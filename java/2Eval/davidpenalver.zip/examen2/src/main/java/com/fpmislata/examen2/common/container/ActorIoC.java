package com.fpmislata.examen2.common.container;


public class ActorIoC {

}
