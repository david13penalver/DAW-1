package com.fpmislata.examen2.domain.entity;

public class Actor {
}
